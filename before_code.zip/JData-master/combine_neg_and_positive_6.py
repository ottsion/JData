#!/usr/bin/env python2
# -*- coding: utf-8-*-
"""
created on 
@author: sunfc
------------------
负样本太大,抽取部分负样本作为训练数据集

"""

import csv

# 抽取部分负样本作为训练数据集
def fetch_negative_sample(negative_data_path, new_negative_data_path):
    num = 1
    csvfile = file('data/'+new_negative_data_path, 'wb')
    writer = csv.writer(csvfile)
    for line in csv.reader(file('data/'+negative_data_path, 'r')):
        if num==1:
            writer.writerow(line)
        elif num % 200 == 0:
            writer.writerow(line)
        num = num + 1
    print num

# 正负样本融合在一起构成训练集
def combine_neg_and_posi(negative_data_path, positive_data_path, train_dataSet_path):
    negative_data = open('data/' + negative_data_path, 'r')
    positive_data = open('data/' + positive_data_path, 'r')
    train_dataSet = open('data/' + train_dataSet_path, 'wb') 
    train_dataSet.write(negative_data.readline())
    for line in negative_data.readlines():
        if line.strip().split(',')[0] =='user_id':
            continue
        else:
            train_dataSet.write(line)
    for line in positive_data.readlines():
        if line.strip().split(',')[0] =='user_id':
            continue
        else:
            train_dataSet.write(line)
    
    
    
