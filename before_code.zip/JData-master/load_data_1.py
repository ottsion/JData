#!/usr/bin/env python2
# -*- coding: utf-8-*-
"""
created on 
@author: sunfc
------------------
    由于数据太大，这里节选部分数据进行假设，最终结果运算时再放入完整数据
------------------
data_of_month:行为数据
    user_id	     用户编号	 
    sku_id	     商品编号	 
    time	     行为时间	 
    model_id	 点击模块编号，如果是点击	 
    type	     1.浏览（指浏览商品详情页）；2.加入购物车；3.购物车删除；4.下单；5.关注；6.点击
	cate	     品类ID	 
    brand	     品牌ID	 

data_user:用户数据
    user_id	     用户ID	 脱敏
    age	         年龄段	 -1表示未知
    sex	         性别	 0表示男，1表示女，2表示保密
    user_lv_cd	 用户等级	 有顺序的级别枚举，越高级别数字越大
    user_reg_dt	 用户注册日期	 粒度到天
    
data_product:商品数据
    sku_id	 商品编号	 脱敏
    attr1	 属性1	 枚举，-1表示未知
    attr2	 属性2	 枚举，-1表示未知
    attr3	 属性3	 枚举，-1表示未知
    cate	 品类ID	 脱敏
    brand	 品牌ID	 脱敏
    
data_comment:评价数据
    dt	                截止到时间	 粒度到天
    sku_id	            商品编号	 脱敏
    comment_num	        累计评论数分段	 0表示无评论，1表示有1条评论， 2表示有2-10条评论， 3表示有11-50条评论， 4表示大于50条评论
    has_bad_comment	    是否有差评	 0表示无，1表示有差评率
    bad_comment_rate	差评数占总评论数的比重
    
"""

import pandas as pd
import numpy as np
import os
from datetime import *

# 数据路径
data_02_month_path = 'JData_Action_201602.csv'
data_02_month_path = 'JData_Action_201602.csv'
data_03_month_path = 'JData_Action_201603.csv'
data_03_month_extra_path = 'JData_Action_201603_extra.csv'
data_04_month_path = 'JData_Action_201604.csv'
data_behave_all_path = 'data_behave_all.csv'

# 抽取出的数据的路径
part_data_02_month_path = 'part_JData_Action_201602.csv'
part_data_02_month_path = 'part_JData_Action_201602.csv'
part_data_03_month_path = 'part_JData_Action_201603.csv'
part_data_03_month_extra_path = 'part_JData_Action_201603_extra.csv'
part_data_04_month_path = 'part_JData_Action_201604.csv'
part_data_behave_all_path = 'part_data_behave_all.csv'


# 解析日期
def parse_date(raw_date):
    entry_date = raw_date
    year, month, day = entry_date.split(" ")[0].split("-")
    return int(year), int(month), int(day)

# 从input中加载数据
def load_data(file_path, code):
    if code=='utf-8':
        data = pd.read_csv(file_path)
    else:
        data = pd.read_csv(file_path, encoding=code)
    return data

# 因为数据太大，这里选用部分数据先在电脑试试，回头上载完整数据
def cut_part_data(data_path):
    file = open('input/' +data_path)
    lines = file.readlines()

    new_data_file = open('data/part_'+data_path,'w')
    index = 0
    for line in lines:
        if index % 10 == 0:
            new_data_file.write(line)
        index = index+1
    new_data_file.close()
    print 'success get part data from',data_path

# 将各月份数据综合起来形成一张表
def part_data_behave_all():
    print 'begin to combine behave data....'
    data_02_behave = open('data/'+part_data_02_month_path)
    data_03_behave = open('data/'+part_data_03_month_path)
    data_03_extra_behave = open('data/'+part_data_03_month_extra_path)
    data_04_behave = open('data/'+part_data_04_month_path)
    data_behave_all = open('data/'+part_data_behave_all_path,'w')
    data_behave_all.writelines(data_02_behave.readlines())
    data_03_behave.readline()  # 读出栏位名
    data_behave_all.writelines(data_03_behave.readlines())
    data_03_extra_behave.readline()  # 读出栏位名
    data_behave_all.writelines(data_03_extra_behave.readlines())
    data_04_behave.readline()  # 读出栏位名
    data_behave_all.writelines(data_04_behave.readlines())
    data_behave_all.close()
    print 'success to combine behave data....'

def data_behave_all():
    print 'begin to combine behave data....'
    data_02_behave = open('input/' + data_02_month_path)
    data_03_behave = open('input/' + data_03_month_path)
    data_03_extra_behave = open('input/' + data_03_month_extra_path)
    data_04_behave = open('input/' + data_04_month_path)

    data_behave_all = open('data/' + data_behave_all_path, 'w')
    data_behave_all.writelines(data_02_behave.readlines())
    data_03_behave.readline()  # 读出栏位名
    data_behave_all.writelines(data_03_behave.readlines())
    data_03_extra_behave.readline()  # 读出栏位名
    data_behave_all.writelines(data_03_extra_behave.readlines())
    data_04_behave.readline()  # 读出栏位名
    data_behave_all.writelines(data_04_behave.readlines())
    data_behave_all.close()
    print 'success to combine behave data....'



def get_part_and_combine_02_03_04():
    # 将大数据取出部分进行测试运算
    print 'begin to split data for easy calculate...'
    cut_part_data(data_02_month_path)
    cut_part_data(data_03_month_path)
    cut_part_data(data_03_month_extra_path)
    cut_part_data(data_04_month_path)
    print 'Down to split data for easy calculate...'
    # 将现有数据的behave表格进行拼接成行为表
    part_data_behave_all()


'''
重要，将总的数据划分为不同的训练测试集（按照开始时间和结束时间）
 @BEGINDAY   开始时间
 @SEPERATEDAY  结束时间
 @data_path   存放路径
'''
def load_data_as_time_need(BEGINDAY, SEPERATEDAY, data_path):
    print 'begin to combine behave data (as time seperated)....'
    data_02_behave = open('input/' + data_02_month_path)
    data_03_behave = open('input/' + data_03_month_path)
    data_03_extra_behave = open('input/' + data_03_month_extra_path)
    data_04_behave = open('input/' + data_04_month_path)
    data_behave_all = open('data/'+data_path, 'w')

    data_03_behave.readline()  # 读出栏位名
    data_03_extra_behave.readline()  # 读出栏位名
    data_04_behave.readline()  # 读出栏位名
    data_behave_all.write(data_02_behave.readline())  # 读入栏位名
    for line in data_02_behave.readlines():
        entry = line.split(",")
        time = date(*parse_date(entry[2]))
        if time >= BEGINDAY and time <= SEPERATEDAY:
            data_behave_all.write(line)
    for line in data_03_behave.readlines():
        entry = line.split(",")
        time = date(*parse_date(entry[2]))
        if time >= BEGINDAY and time <= SEPERATEDAY:
            data_behave_all.write(line)
    for line in data_03_extra_behave.readlines():
        entry = line.split(",")
        time = date(*parse_date(entry[2]))
        if time >= BEGINDAY and time <= SEPERATEDAY:
            data_behave_all.write(line)
    for line in data_04_behave.readlines():
        entry = line.split(",")
        time = date(*parse_date(entry[2]))
        if time >= BEGINDAY and time <= SEPERATEDAY:
            data_behave_all.write(line)

    data_behave_all.close()
    print 'success to combine behave data (as time seperated)....'



# 文件排序
def generate_sortedfile(origin_file_path, filename):
    originfile = open(origin_file_path)

    entrys = originfile.readlines()
    entrys.sort(key=lambda x: x.split(",")[0])
    sortedfile = open(filename, "w")
    for i in entrys:
        sortedfile.write(i)
    sortedfile.close()
    originfile.close()
