#!/usr/bin/env python2
# -*- coding: utf-8-*-
"""
created on 
@author: sunfc
------------------

"""

from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import GradientBoostingClassifier
from sklearn import cross_validation, metrics
import numpy as np
import pandas as pd
from sklearn.grid_search import GridSearchCV


def classify_user_item(train_data_path, test_data_path, result_as_proba_path):
    data = pd.read_csv('data/'+train_data_path)

    data = data.as_matrix()
    X = data[:, 2:-1]  # select columns 0 through end-1
    y = data[:, -1]  # select column end
    print 'len(X):',len(X)
    print 'len(y):',len(y)
    print u'开始训练数据.....'
###############################################################################
# 普通 RF
###############################################################################
#    clf2 = RandomForestClassifier(n_estimators=130)

    clf2 = RandomForestClassifier(oob_score=True, random_state=10)
    # clf2=GradientBoostingClassifier()
    clf2.fit(X, y)
    # clf2 = LogisticRegression().fit(X, y)
    print clf2.oob_score_
    
    y_predprob = clf2.predict_proba(X)[:,1]
    print "AUC Score (Train): %f" % metrics.roc_auc_score(y, y_predprob)
    print clf2.classes_
    return clf2

'''
    print u'结束训练数据.....'
    print u'载入测试数据.....'
    data1 = pd.read_csv('data/' + test_data_path)
    data1 = data1.as_matrix()
    X_test = data1[:, 2:-1]
    print len(X_test)
    print u'开始测试.....'
    result = clf2.predict_proba(X_test)
    print u'测试结束.....'

    print u'保存结果.....'
    f_result = open('data/'+result_as_proba_path, 'w')
    print 'len(result):',len(result)
    for i in range(0, len(result)):
        if i==0:
            print str(result[i][0])
        if i==len(result)-1:
            print str(result[i][0])

        f_result.write(str(result[i][0]) + '\n')
'''



def classify(clf, train_dataSet_path, result_proba_path):
    data1 = pd.read_csv('data/' + train_dataSet_path)
    data1 = data1.as_matrix()
    X_test = data1[:, 2:]
    result = clf.predict_proba(X_test)
    print u'预测结束.....'

    f_result = open('data/' + result_proba_path, 'w')
    print 'len(result):', len(result)
    for i in range(0, len(result)):
        f_result.write(str(result[i][0]) + '\n')


'''
接收数据集和对应的target概率，返回的是[user_id, sku_id, pre]   pre为概率
'''
def combine_tar_and_pre(dataSet_path, proba_path, before_answer_path):
    data = pd.read_csv('data/'+dataSet_path)
    target = pd.read_csv('data/'+proba_path, names='p')

    combine_tar_pre = pd.concat([data,target],axis=1)
    s = pd.concat([combine_tar_pre.user_id, combine_tar_pre.sku_id,combine_tar_pre.p], axis=1)
    ss = s[s.p <= 0.5]
    ss.to_csv('data/'+before_answer_path)

# 根据各个概率值选择合适的用户商品对，作为最后答案
def get_final_answer(before_answer_path, answer_path):
    data = open('data/'+before_answer_path)
    user_list = []
    data.readline()
    temp = {}
    lines = data.readlines()
    for line in lines:
        # 10,16579,66638,0,0.29\n
        info = []
        arr = line.strip().split(',')
        if arr[1] not in user_list:
            user_list.append(arr[1])
            info.append(arr[2])
            info.append(arr[-1])
            temp[arr[1]] = info
        else:
            info_set = temp[arr[1]]
            if info_set[-1] > arr[-1]:
                new_info = []
                new_info.append(arr[2])
                new_info.append(arr[-1])
                temp[arr[1]] = new_info

    answer = open('data/' + answer_path,'w')
    for key in temp.keys():
        sss = key+',' +temp[key][0]+'\n'
        answer.write(sss)
    answer.close()

# 最终得出用户商品键值对
# (three_train_dataSet_path, train_three_result_as_proba_path, three_before_answer_path, three_answer_path)
def output_answer(dataSet_path, proba_path, before_answer_path, answer_path):
    combine_tar_and_pre(dataSet_path, proba_path, before_answer_path)
    get_final_answer(before_answer_path, answer_path)



# 计算召回率
def caculate_callback_pro(positive_data_path, answer_path):
    positive_data = open('data/'+positive_data_path)
    count = 0.0;
    length = 0.0;
    for line in positive_data.readlines():
        length = length + 1
        lineArr = line.strip().split(",")
        answer_data = open('data/'+answer_path)
        for answer in answer_data.readlines():
            answerArr = answer.strip().split(',')
            if (lineArr[0],lineArr[1]) == (answerArr[0], answerArr[1]):
                count = count + 1
    print 'total:',length,' correct:',count
    return count/length
    
    
def caculate_p_c_f(train_data_with_tag_path, answer_path):
    data = open('data/'+train_data_with_tag_path)
    Correct_all_num = 0.0
    Correct_positive_num = 0.0
    positive_length = 0.0
    wrong_num = 0.0
    all_length = 0.0
    for line in data.readlines():
        all_length = all_length + 1
        lineArr = line.strip().split(",")
        # 计算正数据集长度
        if lineArr[-1]=='1':
            positive_length = positive_length + 1

        # 计算当前数据下是否有对应预测结果
        answer_data = open('data/'+answer_path)
        flag = False
        for answer in answer_data.readlines():
            answerArr = answer.strip().split(',')
            # 预测到了，并且正确
            if (lineArr[0],lineArr[1]) == (answerArr[0], answerArr[1]):
                if lineArr[-1]=='1':
                    Correct_positive_num = Correct_positive_num + 1
                    Correct_all_num = Correct_all_num + 1
                    flag = True
        if flag == False and lineArr[-1]=='0':
            Correct_all_num = Correct_all_num + 1
    # Correct_all_num = all_length - wrong_num
    print u"写在前面:",Correct_all_num,Correct_positive_num,positive_length, wrong_num,all_length
    # 计算准确率
    Precise = Correct_all_num/all_length
    #计算召回率
    Recall = Correct_positive_num/positive_length
    # 计算f1
    f = 2*Precise*Recall/(Precise+Recall)
    print u'准确率:',Precise , '召回率:',Recall , 'F1:',f
    
    # 京东要求计算结果
    F11=6*Recall*Precise/(5*Recall+Precise)
    F12=5*Recall*Precise/(2*Recall+3*Precise)
    Score = 0.4*F11 + 0.6*F12
    print 'F11:',F11, 'F12:',F12
    return Score
    
#caculate_p_c_f(two_train_dataSet_path, two_answer_path)
    
    
# 评测方式选择A榜B榜
def evaluate_A(train_data_with_tag_path, answer_path):
    user_id_correct_num = 0.0    # user_id正确数量--
    answer_num = 0.0             # 提交数量
    true_hava_num = 0.0          # A榜数据总量--
    user_id_sku_id_correct_num = 0.0 # A榜user_id+sku_id正确数量
    
    #计算各个数据个数之和
    train_data = open('data/'+train_data_with_tag_path)   
    for line in train_data.readlines():
        lineArr = line.strip().split(",")
        # 计算正数据集长度
        if lineArr[-1]=='1':
            true_hava_num = true_hava_num + 1    
        # 计算当前数据下是否有对应预测结果
        answer_data = open('data/'+answer_path)
        for answer in answer_data.readlines():
            answerArr = answer.strip().split(',')
            
            # 预测用户商品对正确
            if (lineArr[0],lineArr[1]) == (answerArr[0], answerArr[1]):
                if lineArr[-1]=='1':
                    user_id_sku_id_correct_num = user_id_sku_id_correct_num + 1
    answer_data = open('data/'+answer_path)
    for answer in answer_data.readlines():
        answer_num = answer_num + 1
        
    answer_data = open('data/'+answer_path)
    for answer in answer_data.readlines():
        answerArr = answer.strip().split(',')   
        
        train_data = open('data/'+train_data_with_tag_path)   
        for line in train_data.readlines():
            lineArr = line.strip().split(",")
            # 预测user_id正确
            if lineArr[0] == answerArr[0] and lineArr[-1]=='1':
                user_id_correct_num =user_id_correct_num + 1
                break
            
    # A榜 计算方式
    Precise11  = user_id_correct_num/answer_num
    Recall11 = user_id_correct_num/true_hava_num
    Precise12  = user_id_sku_id_correct_num/answer_num
    Recall12 = user_id_sku_id_correct_num/true_hava_num
    
    F11=6*Recall11*Precise11/(5*Recall11+Precise11)
    F12=5*Recall12*Precise12/(2*Recall12+3*Precise12)
    Score=0.4*F11 + 0.6*F12
    print user_id_correct_num 
    print answer_num       
    print true_hava_num        
    print user_id_sku_id_correct_num
    print 'F11,F12: ',F11,F12
    return Score
    
    
    # evaluate_A(two_train_dataSet_path, two_answer_path)
    
    
    
# two_train_dataSet_path
def RF_tiaocan(train_data_path, test_data_path, result_as_proba_path):
    data = pd.read_csv('data/'+train_data_path)

    data = data.as_matrix()
    X = data[:, 2:-1]  # select columns 0 through end-1
    y = data[:, -1]  # select column end
    print 'len(X):',len(X)
    print 'len(y):',len(y)
    print u'开始训练数据.....'
###############################################################################
# 对n_estimators进行网格搜索   130 {'n_estimators': 130},0.90794896477201803)
###############################################################################
    param_test1 = {'n_estimators':range(70,150,10)}
    gsearch1 = GridSearchCV(estimator = RandomForestClassifier(min_samples_split=100,
                                      min_samples_leaf=20,max_depth=8,max_features='sqrt' ,random_state=10), 
                           param_grid = param_test1, scoring='roc_auc',cv=5)
    gsearch1.fit(X,y)
    gsearch1.grid_scores_, gsearch1.best_params_, gsearch1.best_score_   
    
###############################################################################
# 对max_depth进行网格搜索   {'max_depth': 11, 'min_samples_split': 50}, 0.91227004952915036)
# mean: 0.91120, std: 0.01730, params: {'min_samples_split': 70, 'max_depth': 13},
###############################################################################
    param_test2 = {'max_depth':range(3,14,2), 'min_samples_split':range(50,201,20)}
    gsearch2 = GridSearchCV(estimator = RandomForestClassifier(n_estimators= 130, 
                                  min_samples_leaf=20,max_features='sqrt' ,oob_score=True, random_state=10),
    param_grid = param_test2, scoring='roc_auc',iid=False, cv=5)
    gsearch2.fit(X,y)
    gsearch2.grid_scores_, gsearch2.best_params_, gsearch2.best_score_


    # 测试是否有效提高
    rf1 = RandomForestClassifier(n_estimators= 130, max_depth=11, min_samples_split=110,
                                  min_samples_leaf=20,max_features='sqrt' ,oob_score=True, random_state=10)
    rf1.fit(X,y)
    print rf1.oob_score_
    # 0.899313350059
    
###############################################################################
# 对min_samples_split、min_samples_leaf进行网格搜索    
# {'max_depth': 11, 'min_samples_split': 50},0.91227004952915036)
# mean: 0.91120, std: 0.01730, params: {'min_samples_split': 70, 'max_depth': 13},
#    {'min_samples_split': 70, 'min_samples_leaf': 40},
###############################################################################    
    param_test3 = {'min_samples_split':range(80,150,20), 'min_samples_leaf':range(10,60,10)}
    gsearch3 = GridSearchCV(estimator = RandomForestClassifier(n_estimators= 130, max_depth=11,
                                  max_features='sqrt' ,oob_score=True, random_state=10),
    param_grid = param_test3, scoring='roc_auc',iid=False, cv=5)
    gsearch3.fit(X,y)
    gsearch3.grid_scores_, gsearch2.best_params_, gsearch2.best_score_
    
    
###############################################################################
# 最大特征数max_features做调参 
# {'max_depth': 11, 'min_samples_split': 50},0.91227004952915036)
# [mean: 0.91119, std: 0.01891, params: {'min_samples_split': 80, 'min_samples_leaf': 10},
    
# {'max_features': 30},0.90832680399228849)
###############################################################################      
    param_test4 = {'max_features':range(30,70,5)}
    gsearch4 = GridSearchCV(estimator = RandomForestClassifier(n_estimators= 130, max_depth=11, min_samples_split=80,
                                      min_samples_leaf=10 ,oob_score=True, random_state=10),
    param_grid = param_test4, scoring='roc_auc',iid=False, cv=5)
    gsearch4.fit(X,y)
    gsearch4.grid_scores_, gsearch4.best_params_, gsearch4.best_score_
    
    
# 测试
    rf2 = RandomForestClassifier(n_estimators= 130, max_depth=11, min_samples_split=80,
                                  min_samples_leaf=10,max_features=30 ,oob_score=True, random_state=10)
    rf2.fit(X,y)
    print rf2.oob_score_
    # 0.906245873498
###############################################################################
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
