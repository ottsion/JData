#!/usr/bin/env python2
# -*- coding: utf-8-*-
"""
created on 
@author: sunfc
------------------
    提取训练集的正、负样本--加标签
    
"""

import csv
import os


# train_one_label_data_path, train_one_train_feature_path, 'one_'

negative_data = 'negative.csv'
positive_data = 'positive.csv'
# ['user_id', 'sku_id', 'time', 'model_id', 'type', 'cate', 'brand']
# 1.浏览（指浏览商品详情页）；2.加入购物车；3.购物车删除；4.下单；5.关注；6.点击
def fetch_sample(test_data_path, feature_data_path, code):
    buy = set()
    for line in csv.reader(file('data/'+test_data_path, 'rb')):
        if line[4] == '4':
            buy.add((line[0], line[1]))  # 正例集

    negative_file = file('data/'+code+negative_data, 'wb')
    negative_writer = csv.writer(negative_file)

    positive_file = file('data/'+code+positive_data, 'wb')
    positive_writer = csv.writer(positive_file)

    print 'open ',feature_data_path,'to add label'

    for line in csv.reader(file('data/'+feature_data_path, 'rb')):
        if line[0]=='user_id':
            line.extend('r')
            negative_writer.writerow((line))
            positive_writer.writerow((line))
        elif (line[0], line[1]) not in buy:
            line.append(0)
            negative_writer.writerow(line)  # 负例特征
        else:
            line.append(1)
            positive_writer.writerow(line)  # 正例特征


