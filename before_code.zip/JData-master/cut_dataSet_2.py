#!/usr/bin/env python2
# -*- coding: utf-8-*-
"""
created on 
@author: sunfc
------------------
主要其任务是切分数据集为训练集和测试集
    提供2016-02-01到2016-04-15日用户集合U中的用户，对商品集合S中部分商品的行为、评价、用户数据；提供部分候选商品的数据P。
选手从数据中自行组成特征和数据格式，自由组合训练测试数据比例。

预测数据部分：
    2016-04-16到2016-04-20用户是否下单P中的商品，每个用户只会下单一个商品；抽取部分下单用户数据，A榜使用50%的测试数据来计算分数；B榜使用另外50%的数据计算分数。

个人做法：
    窗口滑动法
    以2016-02-01到2016-03-31数据   预测2016-04-01到2016-04-15某用户是否下单某商品
    以2016-02-16到2016-04-15数据   预测2016-04-16到2016-04-20某用户是否下单某商品

"""


import os
from datetime import *

# 数据位置
data_behave_all_path = 'data/part_data_behave_all.csv'

# 拆分后的两部分数据，前部分为train主要是训练部分，后部分为test主要用来提取label
train_file_path = "train_behave.csv"
test_file_path = "test_behave.csv"
all_file_path = "all_behave.csv"
sorted_train_file_path = 'train_behave_sorted.csv'
sorted_test_file_path = "test_behave_sorted.csv"
sorted_all_file_path = "all_behave_sorted.csv"

# 解析日期
def parse_date(raw_date):
    entry_date = raw_date
    year, month, day = entry_date.split(" ")[0].split("-")
    return int(year), int(month), int(day)


# 文件排序
def generate_sortedfile(origin_file_path, filename):
    originfile = open('data/'+origin_file_path)
    column_name = originfile.readline()
    entrys = originfile.readlines()
    entrys.sort(key=lambda x: x.split(",")[0])
    sortedfile = open('data/'+filename, "w")
    sortedfile.write(column_name)
    for i in entrys:
        sortedfile.write(i)
    sortedfile.close()
    originfile.close()
    #os.remove(origin_file_path)


# 分割数据  分割为训练集和测试集
def split_file(raw_file_path, train_file_path, test_file_path, seperate_day, begin_date):


    raw_file = open('data/'+raw_file_path)
    t_train = open('data/'+train_file_path, 'w')
    t_test = open('data/'+test_file_path, 'w')
    t_all = open('data/'+all_file_path, 'w')

    interval_days = (seperate_day - begin_date).days
    column_name = raw_file.readline()  # 读出栏位名
    t_train.write(column_name)
    t_test.write(column_name)
    t_all.write(column_name)
    for line in raw_file:
        entry = line.split(",")
        # user_id,item_id,behavior_type,user_geohash,item_category,time
        # user_id, sku_id, time, model_id, type, cate, brand,
        entry_date = date(*parse_date(entry[2]))
        date_delta = (entry_date - begin_date).days
        # 如果到开始那天的时间距离小于interval_days，则表示其为训练集，否则就是测试集，主要用来生成label，并不是说是真的测试集部分
        if date_delta <= interval_days:
            t_train.write(line)
        else:
            t_test.write(line)
        t_all.write(line)

    t_all.close()
    t_test.close()
    t_train.close()
    raw_file.close()
    print 'Down part one (split behave from one time point)...    escape'
    #generate_sortedfile(train_file_path, sorted_train_file_path)
    print "generate behave train_file completed    escape"
    #generate_sortedfile(test_file_path, sorted_test_file_path)
    print "generate behave validation_file completed    escape"
    #generate_sortedfile(all_file_path, sorted_all_file_path)
    print "generate behave all_file completed"
    print 'Down part two (sorted by user_id)...'


def cut_data_as_time(BEGINDAY, SEPERATEDAY):
    #以2016-02-01到2016-03-31数据   预测2016-04-01到2016-04-15某用户是否下单某商品
    #以2016-02-16到2016-04-15数据   预测2016-04-16到2016-04-20某用户是否下单某商品
    #BEGINDAY = date(2016, 02, 01)
    #SEPERATEDAY = date(2016, 03, 31)

    begin_time = datetime.now()
    split_file(data_behave_all_path, train_file_path, test_file_path, SEPERATEDAY, BEGINDAY)
    print u'运行耗时:',datetime.now() - begin_time


