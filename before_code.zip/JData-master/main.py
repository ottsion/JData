#!/usr/bin/env python2
# -*- coding: utf-8-*-
"""
created on 
@author: sunfc
------------------

"""
import sys
sys.path.append("..")
sys.path.append('code')
from datetime import *
import pandas as pd
import load_data_1
import cut_dataSet_2
import deal_data_3
import feature_generate_4
import feature_generate_4_1
import get_label_5
import combine_neg_and_positive_6
import classify_and_predict_7

part_data_behave_all_path = 'part_data_behave_all.csv'

train_one_data_path = 'train_one_data.csv'
train_one_train_data_path = 'train_one_train_data.csv'
train_one_label_data_path = 'train_one_label_data.csv'
train_one_train_feature_path = 'train_one_train_feature.csv'
train_one_train_feature_path_pre1 = 'train_one_train_feature_pre1.csv'

train_two_data_path = 'train_two_data.csv'
train_two_train_data_path = 'train_two_train_data.csv'
train_two_label_data_path = 'train_two_label_data.csv'
train_two_train_feature_path = 'train_two_train_feature.csv'
train_two_train_feature_path_pre1 = 'train_two_train_feature_pre1.csv'

train_three_data_path = 'train_three_data.csv'
train_three_train_data_path = 'train_three_train_data.csv'
train_three_label_data_path = 'train_three_label_data.csv'  # 理论为空
train_three_train_feature_path = 'train_three_train_feature.csv'
train_three_train_feature_path_pre1 = 'train_three_train_feature_pre1.csv'

one_negative_data_path = 'one_negative.csv'
one_negative_data_after_sampling_path = 'one_negative_after_sampling_data.csv'
one_positive_data_path = 'one_positive.csv'
one_train_dataSet_path = 'one_train_dataSet.csv'
one_train_dataSet_after_clean_path = 'one_train_dataSet_1.csv'

two_negative_data_path = 'two_negative.csv'
two_negative_data_after_sampling_path = 'two_negative_after_sampling_data.csv'
two_positive_data_path = 'two_positive.csv'
two_train_dataSet_path = 'two_train_dataSet.csv'
two_train_dataSet_after_clean_path = 'two_train_dataSet_1.csv'

three_negative_data_path = 'three_negative.csv'
three_negative_data_after_sampling_path = 'three_negative_after_sampling_data.csv'
three_positive_data_path = 'three_positive.csv'
three_train_dataSet_path = train_three_train_feature_path
three_train_dataSet_after_clean_path = 'three_train_dataSet_after_clean.csv'

train_one_and_two_result_as_proba_path = 'train_one_and_two_result_as_proba_path.csv'
train_three_result_as_proba_path = 'train_three_result_as_proba_path.csv'

answer_path = 'answer.csv'
two_before_answer_path = 'two_before_answer.csv'
two_answer_path = 'two_answer.csv'
three_before_answer_path = 'three_before_answer.csv'
three_answer_path = 'three_answer.csv'



comment_data_path = 'input/JData_Comment.csv';
product_data_path = 'input/JData_Product.csv';
user_data_path = 'input/JData_User.csv';
all_user_behave_data_path = 'data/all_behave.csv';
train_user_behave_data_path = 'data/train_behave.csv';

train_feature_data_path = 'data/train_feature_data.csv'

user_data_utf8_path = 'data/JData_User.csv';
user_data_utf8_after_path = 'data/JData_User_after.csv';
user_data_final_path = 'data/user_data_final.csv'
user_data_final_path_new = 'data/user_final_data.csv'      #新增，删除上表中错误信息
comment_data_final_path = 'data/comment_final_data.csv'


if __name__=="__main__":
    ####################################################################
    #                           准备数据                                #
    ####################################################################
    print u'开始准备数据，进行数据融合.....'
    # 构建总表   存入part_data_behave_all_path = 'part_data_behave_all.csv'
    # load_data_1.part_data_behave_all()
    load_data_1.data_behave_all()
    print u'融合完毕，进行拆分测试训练集.....'
    # 构建分表
    begin = date(2016, 03, 10)
    end = date(2016, 04, 10)
    load_data_1.load_data_as_time_need(begin, end, train_one_data_path)
    begin = date(2016, 03, 15)
    end = date(2016, 04, 15)
    load_data_1.load_data_as_time_need(begin, end, train_two_data_path)
    begin = date(2016, 03, 20)
    end = date(2016, 04, 15)
    load_data_1.load_data_as_time_need(begin, end, train_three_data_path)
    print u'拆分完毕，数据准备阶段完成.....'
    ####################################################################
    #                          划分数据集                                #
    ####################################################################
    print u'开始划分数据集.....'
    # 以2016-03-10到2016-04-05数据   预测2016-04-06到2016-04-10某用户是否下单某商品
    begin = date(2016, 03, 10)
    seperate = date(2016, 04, 05)
    cut_dataSet_2.split_file(train_one_data_path, train_one_train_data_path\
        , train_one_label_data_path, seperate, begin)
    print u'第一阶段完成.....'
    # 以2016-03-15到2016-04-10数据   预测2016-04-11到2016-04-15某用户是否下单某商品
    begin = date(2016, 03, 15)
    seperate = date(2016, 04, 10)
    cut_dataSet_2.split_file(train_two_data_path, train_two_train_data_path\
                             , train_two_label_data_path, seperate, begin)
    print u'第二阶段完成.....'
    # 以2016-03-20到2016-04-15数据   预测2016-04-16到2016-04-20某用户是否下单某商品
    begin = date(2016, 03, 20)
    seperate = date(2016, 04, 15)
    cut_dataSet_2.split_file(train_three_data_path, train_three_train_data_path\
                             , train_three_label_data_path, seperate, begin)
    print u'第三阶段完成.....'
    print u'成功划分数据集.....'
    ####################################################################
    #                         生成特征维度集                             #
    ####################################################################
    print u'开始生成特征维度集.....'
    # 以2016-03-10到2016-04-05数据   预测2016-04-06到2016-04-10某用户是否下单某商品
    item_brand = dict()
    feature_generate_4.fetch_feature(train_one_train_data_path, train_one_train_feature_path_pre1\
        , item_brand)
    feature_generate_4_1.fetch_feature_1(train_one_train_feature_path_pre1, user_data_final_path, \
                                         comment_data_final_path, train_one_train_feature_path)
    print u'第一数据集完成.....'
    # 以2016-03-15到2016-04-10数据   预测2016-04-11到2016-04-15某用户是否下单某商品
    item_brand = dict()
    feature_generate_4.fetch_feature(train_two_train_data_path, train_two_train_feature_path_pre1 \
                                     , item_brand)
    feature_generate_4_1.fetch_feature_1(train_two_train_feature_path_pre1, user_data_final_path, \
                                         comment_data_final_path, train_two_train_feature_path)
    print u'第二数据集完成.....'
    # 以2016-03-20到2016-04-15数据   预测2016-04-16到2016-04-20某用户是否下单某商品
    item_brand = dict()
    feature_generate_4.fetch_feature(train_three_train_data_path, train_three_train_feature_path_pre1 \
                                     , item_brand)
    feature_generate_4_1.fetch_feature_1(train_three_train_feature_path_pre1, user_data_final_path, \
                                         comment_data_final_path, train_three_train_feature_path)
    print u'第三数据集完成.....'
    print u'成功生成特征维度集.....'
    ####################################################################
    #                           打上标签                                #
    ####################################################################
    print u'开始打上标签.....'
    # 以2016-03-01到2016-04-05数据   预测2016-04-06到2016-04-10某用户是否下单某商品
    get_label_5.fetch_sample(train_one_label_data_path, train_one_train_feature_path, 'one_')
    print u'第一阶段完成.....'
    # 以2016-03-06到2016-04-10数据   预测2016-04-11到2016-04-15某用户是否下单某商品
    get_label_5.fetch_sample(train_two_label_data_path, train_two_train_feature_path, 'two_')
    print u'第二阶段完成.....'
    print u'成功打上标签.....'
    ####################################################################
    #                      抽取正负样本组成训练集                          #
    ####################################################################
    print u'开始抽取正负样本组成训练集.....one'
    # 抽取部分负数据集作为负样本
    combine_neg_and_positive_6.fetch_negative_sample(one_negative_data_path, one_negative_data_after_sampling_path)
    # 融合正负样本数据作为训练集
    combine_neg_and_positive_6.combine_neg_and_posi(one_negative_data_after_sampling_path, one_positive_data_path,
                                                    one_train_dataSet_path)
    print u'成功抽取正负样本组成训练集.....one'
    print u'开始抽取正负样本组成训练集.....two'
    # 抽取部分负数据集作为负样本
    combine_neg_and_positive_6.fetch_negative_sample(two_negative_data_path, two_negative_data_after_sampling_path)
    # 融合正负样本数据作为训练集
    combine_neg_and_positive_6.combine_neg_and_posi(two_negative_data_after_sampling_path, two_positive_data_path,
                                                    two_train_dataSet_path)
    print u'成功抽取正负样本组成训练集.....two'
    
    ####################################################################
    #                  将训练集与预测集进行数据清洗                     #
    ####################################################################    
    # 清理 one_train_dataSet_path（数据+标签）
    
    # 清理 two_train_dataSet_path（数据+标签）
    
    # 清理 train_three_train_feature_path（只有数据）
    deal_data_3.clean_data(one_train_dataSet_path, one_train_dataSet_after_clean_path)
    deal_data_3.clean_data(two_train_dataSet_path, two_train_dataSet_after_clean_path)
    deal_data_3.clean_data(three_train_dataSet_path, three_train_dataSet_after_clean_path)
    ####################################################################
    #                           分类及预测                               #
    ####################################################################
    # 预先训练one数据集预测two数据集
    print u'预先训练one数据集预测two数据集.....'
    clf = classify_and_predict_7.classify_user_item(one_train_dataSet_path, two_train_dataSet_path, train_one_and_two_result_as_proba_path)
    # classify_and_predict_7.combine_tar_and_pre(two_train_dataSet_path, train_one_and_two_result_as_proba_path)
    classify_and_predict_7.output_answer(two_train_dataSet_path, train_one_and_two_result_as_proba_path, two_before_answer_path, two_answer_path)
    pro = classify_and_predict_7.caculate_callback_pro(two_positive_data_path, two_answer_path)
    print pro

    print u'真实数据集预测.....'
    classify_and_predict_7.classify(clf, three_train_dataSet_path, train_three_result_as_proba_path)
    classify_and_predict_7.output_answer(three_train_dataSet_path, train_three_result_as_proba_path, three_before_answer_path, three_answer_path)
