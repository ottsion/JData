#!/usr/bin/env python2
# -*- coding: utf-8-*-
"""
created on 
@author: sunfc
------------------
    
"""


import pandas as pd
import datetime


# 需自备表格如下：
# 数据路径
data_02_month_path = 'JData_Action_201602.csv'
data_03_month_path = 'JData_Action_201603.csv'
data_03_month_extra_path = 'JData_Action_201603_extra.csv'
data_04_month_path = 'JData_Action_201604.csv'
Product_data_path = 'JData_Product.csv'
User_data_path = 'JData_User.csv'
Comment_data_path = 'JData_Comment.csv'






# 清理不需要出现的用户和不需要出现的商品
def clean_noUse_user_and_noUser_product(dataSet_path, after_dataSet_path):
    # 清理不需要的商品  下单商品必须为P中商品
    train_data = pd.read_csv('data/'+dataSet_path)
    product_data = pd.read_csv('input/'+Product_data_path)
    sku_all = product_data.sku_id
    new_train_data = train_data[train_data.sku_id.isin(sku_all)]
    new_train_data.to_csv('data/'+after_dataSet_path, index=False)

    
    

# 清理异常数据
def clean_unNormal_data(after_dataSet_path):
    train_data = pd.read_csv('data/'+after_dataSet_path)
    train_data.describe()
    train_data = train_data[train_data.user_item_click<54] 
    train_data = train_data[train_data.user_click<1500] 
    train_data = train_data[train_data.usr_item_hide<18] 
    
    train_data = train_data[train_data.user_hide<20] 
    train_data = train_data[train_data.usr_item_shop_basket<15] 
    train_data = train_data[train_data.user_basket<50] 

    train_data = train_data[train_data.user_view<1000] 
    
    train_data.to_csv('data/'+after_dataSet_path, index=False)
    

    

def clean_data(dataSet_path, after_dataSet_path):
    clean_noUse_user_and_noUser_product(dataSet_path, after_dataSet_path)
    clean_unNormal_data(after_dataSet_path)


